import React from 'react';

const Loading = () => (
  <div>
    Loading...
  </div>
);

export default Loading;
