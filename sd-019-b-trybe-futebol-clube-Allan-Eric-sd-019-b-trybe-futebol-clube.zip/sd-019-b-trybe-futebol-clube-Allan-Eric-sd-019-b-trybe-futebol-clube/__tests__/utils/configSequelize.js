module.exports = {
  username: 'root',
  password: '123456',
  database: 'TRYBE_FUTEBOL_CLUBE',
  host: 'localhost',
  dialect: 'mysql',
  dialectOptions: {
    timezone: 'Z',
  },
  logging: false,
};
